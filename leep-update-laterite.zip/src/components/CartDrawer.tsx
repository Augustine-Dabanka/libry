"use client";

import { useEffect, useState } from "react";
import { type CartItem, getCart, removeFromCart, clearCart, onCartChange } from "@/lib/cart";
import { checkoutCart, paystackReady } from "@/app/actions/purchases";
import { formatPrice } from "@/lib/types";

import Glyph from "@/components/Glyph";
const PAYSTACK_KEY = process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY || "";
const PAYSTACK_CURRENCY = process.env.NEXT_PUBLIC_PAYSTACK_CURRENCY || "USD";
// Currency units charged per $1 of list price (1 for USD; the GHS-per-USD rate
// for a Ghana account). Kept in sync with the server-side check.
const PAYSTACK_RATE = Number(process.env.NEXT_PUBLIC_PAYSTACK_USD_RATE || "1") || 1;

// Real Paystack checkout runs only when the SERVER confirms it's fully
// configured (secret key set + enabled) — so we never open the card iframe when
// the payment couldn't be verified afterward. Otherwise checkout is simulated
// (no charge, books still added), which keeps the pre-launch store usable.

// Load Paystack's inline script once, on demand.
function loadPaystack(): Promise<unknown> {
  return new Promise((resolve, reject) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    if ((window as any).PaystackPop) return resolve((window as any).PaystackPop);
    const s = document.createElement("script");
    s.src = "https://js.paystack.co/v1/inline.js";
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    s.onload = () => resolve((window as any).PaystackPop);
    s.onerror = () => reject(new Error("Could not load Paystack."));
    document.body.appendChild(s);
  });
}

// Slide-over cart. Mounted once in the navbar; opens on the "libry:cart-open"
// event (fired by the Cart button and by Add-to-cart).
export default function CartDrawer({ email }: { email?: string }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<CartItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [live, setLive] = useState(false);

  useEffect(() => {
    paystackReady().then(setLive).catch(() => setLive(false));
  }, []);

  useEffect(() => {
    setItems(getCart());
    const off = onCartChange(() => setItems(getCart()));
    const onOpen = () => setOpen(true);
    window.addEventListener("libry:cart-open", onOpen);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      off();
      window.removeEventListener("libry:cart-open", onOpen);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const total = items.reduce((s, i) => s + (Number(i.price) || 0), 0);

  async function record(reference: string) {
    const res = await checkoutCart(
      items.map((i) => ({ id: Number(i.id), price: Number(i.price) || 0 })),
      reference
    );
    setBusy(false);
    if (res?.error) {
      setErr(res.error);
      return;
    }
    clearCart();
    setDone(live ? "Payment complete — enjoy your books." : "Added to your library — enjoy.");
  }

  async function checkout() {
    setErr(null);
    setBusy(true);

    // Real Paystack only when the server confirms it's configured; else simulate.
    if (live && email && PAYSTACK_KEY) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const Paystack: any = await loadPaystack();
        const handler = Paystack.setup({
          key: PAYSTACK_KEY,
          email,
          amount: Math.round(total * PAYSTACK_RATE * 100), // minor units (cents/pesewas)
          currency: PAYSTACK_CURRENCY,
          ref: `libry-${Date.now()}`,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          callback: (resp: any) => {
            record(resp.reference || `paystack-${Date.now()}`);
          },
          onClose: () => setBusy(false),
        });
        handler.openIframe();
      } catch (e) {
        setBusy(false);
        setErr(e instanceof Error ? e.message : "Checkout failed.");
      }
      return;
    }

    // Simulated checkout — no real charge.
    await record(`demo-${Date.now()}`);
  }

  return (
    <>
      {/* backdrop */}
      <div
        onClick={() => setOpen(false)}
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.5)",
          opacity: open ? 1 : 0,
          pointerEvents: open ? "auto" : "none",
          transition: "opacity 0.25s ease",
          zIndex: 1300,
        }}
        aria-hidden="true"
      />

      {/* panel */}
      <aside
        role="dialog"
        aria-label="Cart"
        aria-hidden={!open}
        style={{
          position: "fixed",
          top: 0,
          right: 0,
          height: "100dvh",
          width: "min(400px, 92vw)",
          background: "var(--charcoal)",
          borderLeft: "1px solid var(--border)",
          // No shadow and hidden while closed, so its edge never shades the page.
          boxShadow: open ? "-24px 0 60px rgba(0,0,0,0.25)" : "none",
          visibility: open ? "visible" : "hidden",
          transform: open ? "translateX(0)" : "translateX(100%)",
          transition: open ? "transform 0.28s cubic-bezier(0.4,0,0.2,1)" : "transform 0.28s cubic-bezier(0.4,0,0.2,1), visibility 0s linear 0.28s",
          zIndex: 1301,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "1.3rem 1.4rem", borderBottom: "1px solid var(--border)" }}>
          <h3 style={{ fontSize: "1.15rem" }}>Your cart {items.length ? `(${items.length})` : ""}</h3>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Close cart"
            style={{ background: "transparent", border: "none", color: "var(--muted)", fontSize: "1.5rem", cursor: "pointer", lineHeight: 1 }}
          >
            ×
          </button>
        </header>

        <div style={{ flex: 1, overflowY: "auto", padding: "1rem 1.4rem" }}>
          {done ? (
            <div style={{ textAlign: "center", fontFamily: "var(--sans)", padding: "3rem 1rem" }}>
              <div style={{ fontSize: "2.4rem", marginBottom: "0.6rem", color: "var(--success)" }}>✓</div>
              <p style={{ color: "var(--ivory)", fontSize: "1.05rem", marginBottom: "1rem" }}>{done}</p>
              <a
                href="/my-library?tab=purchased"
                onClick={() => { setDone(null); setOpen(false); }}
                style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "0.8rem 1.4rem", background: "var(--gold)", color: "#12100E", borderRadius: 999, fontFamily: "var(--sans)", fontWeight: 700, fontSize: "0.95rem", textDecoration: "none" }}
              >
                View My Library
              </a>
            </div>
          ) : items.length === 0 ? (
            <div style={{ textAlign: "center", color: "var(--muted)", fontFamily: "var(--sans)", padding: "3rem 1rem" }}>
              <div style={{ fontSize: "2rem", marginBottom: "0.6rem" }}><Glyph e="🛒" /></div>
              <p style={{ marginBottom: "0.3rem", color: "var(--ivory)" }}>Your cart is empty.</p>
              <p style={{ fontSize: "0.9rem" }}>
                Add a premium book from the{" "}
                <a href="/catalog" style={{ color: "var(--gold)" }} onClick={() => setOpen(false)}>
                  catalog
                </a>
                .
              </p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "0.8rem" }}>
              {items.map((i) => (
                <div key={i.id} style={{ display: "flex", gap: "0.8rem", alignItems: "center", padding: "0.7rem", background: "var(--stone)", border: "1px solid var(--border)", borderRadius: 12 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <a href={`/book/${i.id}`} onClick={() => setOpen(false)} style={{ fontFamily: "var(--serif)", color: "var(--ivory)", fontSize: "1rem", display: "block", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {i.title}
                    </a>
                    <span style={{ color: "var(--muted)", fontFamily: "var(--sans)", fontSize: "0.82rem" }}>{i.author || "Unknown author"}</span>
                  </div>
                  <span className="price" style={{ whiteSpace: "nowrap" }}>{formatPrice(i.price)}</span>
                  <button
                    type="button"
                    onClick={() => removeFromCart(i.id)}
                    aria-label={`Remove ${i.title}`}
                    style={{ background: "transparent", border: "none", color: "var(--muted)", cursor: "pointer", fontSize: "1.2rem", lineHeight: 1 }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && !done ? (
          <footer
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "0.9rem",
              padding: "1.2rem 1.4rem calc(1.2rem + env(safe-area-inset-bottom))",
              borderTop: "1px solid var(--border)",
              background: "var(--charcoal)",
              fontFamily: "var(--sans)",
            }}
          >
            {/* Summary line */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: "0.75rem" }}>
              <span style={{ color: "var(--muted)", fontSize: "0.85rem" }}>
                Subtotal · {items.length} item{items.length === 1 ? "" : "s"}
              </span>
              <span className="price" style={{ fontSize: "1.35rem", fontWeight: 700, whiteSpace: "nowrap" }}>{formatPrice(total)}</span>
            </div>

            {/* Primary action — full-width pill, can never collapse into a circle */}
            <button
              type="button"
              onClick={checkout}
              disabled={busy}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "0.5rem",
                width: "100%",
                boxSizing: "border-box",
                minHeight: 52,
                padding: "0 1.25rem",
                margin: 0,
                background: "var(--gold)",
                color: "#12100E",
                border: "none",
                borderRadius: 14,
                fontFamily: "var(--sans)",
                fontWeight: 700,
                fontSize: "1rem",
                letterSpacing: "0.01em",
                lineHeight: 1.2,
                textAlign: "center",
                whiteSpace: "nowrap",
                cursor: busy ? "default" : "pointer",
                opacity: busy ? 0.7 : 1,
                transition: "opacity 0.15s ease, filter 0.15s ease",
              }}
              onMouseEnter={(e) => { if (!busy) e.currentTarget.style.filter = "brightness(1.05)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.filter = "none"; }}
            >
              {busy ? "Processing…" : live ? `Pay ${formatPrice(total)}` : `Checkout — ${formatPrice(total)}`}
            </button>

            {err ? (
              <p style={{ color: "var(--terracotta)", fontSize: "0.8rem", textAlign: "center", margin: 0 }}>{err}</p>
            ) : (
              <p style={{ color: "var(--muted)", fontSize: "0.76rem", textAlign: "center", margin: 0, lineHeight: 1.5 }}>
                <Glyph e="🔒" /> {live ? "Secured by Paystack" : "Free while we finish secure payments — no card needed."}
              </p>
            )}
          </footer>
        ) : null}
      </aside>
    </>
  );
}
