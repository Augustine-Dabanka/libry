import { createClient } from "@/lib/supabase/server";
import { serviceClient } from "@/lib/supabase/service";
import ReaderView from "@/components/ReaderView";
import InteractiveReader from "@/components/InteractiveReader";
import ComicReader from "@/components/ComicReader";
import { firstChapterExcerpt } from "@/lib/chapters";
import { parseInteractive } from "@/lib/interactive";
import { parseComic, isComicType, defaultComicMode } from "@/lib/comic";
import { isMatureRating } from "@/lib/content";

import Glyph from "@/components/Glyph";
function Gate({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: "2rem", textAlign: "center", background: "var(--charcoal)" }}>
      <div style={{ maxWidth: 420 }}>{children}</div>
    </div>
  );
}

export default async function ReaderPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ sample?: string }>;
}) {
  const { id } = await params;
  const { sample } = await searchParams;
  const isSample = sample === "1" || sample === "true";
  const supabase = await createClient();

  const { data: book } = await supabase
    .from("books")
    .select("id, title, author, price, user_id, type, age_rating, category")
    .eq("id", id)
    .maybeSingle();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!book) {
    return (
      <Gate>
        <h1>Story not found</h1>
        <p style={{ color: "var(--muted)", marginTop: "0.6rem" }}>
          <a href="/catalog" style={{ color: "var(--gold)" }}>Back to catalog →</a>
        </p>
      </Gate>
    );
  }

  // ---- 18+ age gate: block Mature titles unless the reader enabled it ----
  if (isMatureRating((book as { age_rating?: string }).age_rating)) {
    let showMature = false;
    if (user) {
      const sm = await supabase.from("profiles").select("show_mature").eq("id", user.id).maybeSingle();
      showMature = !!sm.data?.show_mature;
    }
    if (!showMature) {
      return (
        <Gate>
          <div style={{ fontSize: "2rem", marginBottom: "0.6rem" }}><Glyph e="🔞" /></div>
          <h1 style={{ marginBottom: "0.6rem" }}>This is an 18+ title</h1>
          <p style={{ color: "var(--muted)", marginBottom: "1.4rem" }}>
            Mature content is off by default. Turn on <strong style={{ color: "var(--ivory)" }}>Show mature content</strong> in Settings to read it.
          </p>
          <div style={{ display: "flex", gap: "0.7rem", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="/settings" className="btn btn-gold">Open Settings</a>
            <a href={`/book/${book.id}`} className="btn btn-outline">Back</a>
          </div>
        </Gate>
      );
    }
  }

  const isFree = (book.price ?? 0) <= 0;
  const isOwner = !!user && (book as { user_id?: string }).user_id === user.id;
  let purchased = false;
  if (user && !isFree && !isOwner) {
    const p = await supabase.from("purchases").select("book_id").eq("user_id", user.id).eq("book_id", book.id).maybeSingle();
    purchased = !!p.data;
  }
  const canFull = isFree || isOwner || purchased;
  // Guests preview the first chapter of every book; signing up unlocks the rest
  // (free books) or the purchase step (paid books).
  const showSample = isSample || !canFull || !user;
  const locked = !canFull && (book.price ?? 0) > 0;

  // Book text is no longer readable straight from the database by visitors
  // (that let anyone download paid books). The server fetches it here, after
  // the access check above, and only hands the reader what it may see.
  let content = "";
  {
    const svc = serviceClient();
    const r = svc
      ? await svc.from("books").select("content").eq("id", book.id).maybeSingle()
      : await supabase.from("books").select("content").eq("id", book.id).maybeSingle();
    content = ((r.data as { content?: string | null } | null)?.content) ?? "";
  }

  // ---- Interactive stories: real, choice-driven branching ----
  if ((book.type || "").toLowerCase() === "interactive" && content && !canFull) {
    // Paid interactive stories used to play in full for everyone.
    return (
      <Gate>
        <h1 style={{ marginBottom: "0.6rem" }}>Unlock {book.title}</h1>
        <p style={{ color: "var(--muted)", marginBottom: "1.4rem" }}>This interactive story is part of the paid catalog.</p>
        <a href={`/book/${book.id}`} className="btn btn-gold">{user ? "See unlock options" : "Sign in to unlock"}</a>
      </Gate>
    );
  }
  if ((book.type || "").toLowerCase() === "interactive" && content) {
    const story = parseInteractive(content);
    if (story.chapters.length >= 1) {
      return (
        <InteractiveReader
          bookId={String(book.id)}
          title={book.title}
          author={book.author}
          story={story}
          userEmail={user?.email ?? null}
        />
      );
    }
  }

  // ---- Standard reader with the purchase gate ----

  // ---- Comics: image/panel reader (webtoon scroll or page-by-page) ----
  if (isComicType(book.type) && content) {
    const comic = parseComic(content);
    if (comic.pages.some((p) => p.kind === "image")) {
      // Preview locked comics with the first few pages.
      let pages = comic.pages;
      if (showSample && locked) {
        let shown = 0;
        pages = [];
        for (const p of comic.pages) {
          pages.push(p);
          if (p.kind === "image" && ++shown >= 4) break;
        }
      }
      return (
        <ComicReader
          bookId={String(book.id)}
          title={book.title}
          author={book.author}
          pages={pages}
          userEmail={user?.email ?? null}
          sample={showSample && locked}
          locked={showSample && locked}
          signedIn={!!user}
          price={book.price}
          defaultMode={defaultComicMode((book as { category?: string | null }).category)}
        />
      );
    }
  }

  const { excerpt, truncated } = showSample ? firstChapterExcerpt(content) : { excerpt: content, truncated: false };

  let userName: string | null = null;
  if (user) {
    const pr = await supabase.from("profiles").select("full_name, username").eq("id", user.id).maybeSingle();
    userName = pr.data?.full_name || pr.data?.username || (user.email ? user.email.split("@")[0] : null);
  }

  // Is this paid book part of Unlimited? (column from 0044; false if not migrated yet)
  let inUnlimited = false;
  if (locked && (book.price ?? 0) > 0) {
    const au = await supabase.from("books").select("allow_unlimited").eq("id", book.id).maybeSingle();
    inUnlimited = !au.error && !!(au.data as { allow_unlimited?: boolean } | null)?.allow_unlimited;
  }

  return (
    <ReaderView
      bookId={String(book.id)}
      title={book.title}
      author={book.author}
      content={showSample ? excerpt : content}
      userEmail={user?.email ?? null}
      userId={user?.id ?? null}
      userName={userName}
      creatorId={(book as { user_id?: string | null }).user_id ?? null}
      sample={showSample && (truncated || locked)}
      signedIn={!!user}
      locked={locked}
      price={book.price}
      inUnlimited={inUnlimited}
    />
  );
}
