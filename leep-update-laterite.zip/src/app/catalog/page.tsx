import { createClient } from "@/lib/supabase/server";
import AppNav from "@/components/AppNav";
import BookMini from "@/components/BookMini";
import CatalogSort from "@/components/CatalogSort";
import { allowedRatings, GENRES } from "@/lib/content";
import { type Book } from "@/lib/types";

// Every genre shows as a browse chip. Fiction / Non-Fiction are Format chips
// (books.type), so they're not repeated here as genres.
const BROWSE_GENRES: string[] = GENRES.filter((g) => g !== "Fiction" && g !== "Non-Fiction");

type CatBook = Book & { is_free?: boolean | null };

function Shelf({ title, href, books }: { title: string; href: string; books: CatBook[] }) {
  if (books.length === 0) return null;
  return (
    <section className="section" style={{ paddingTop: "1.2rem", paddingBottom: 0 }}>
      <div className="section-header">
        <h2>{title}</h2>
        <a href={href} style={{ color: "var(--gold)", fontFamily: "var(--sans)" }}>
          View all →
        </a>
      </div>
      <div className="book-grid-mini">
        {books.slice(0, 12).map((b) => (
          <BookMini key={b.id} book={b} />
        ))}
      </div>
    </section>
  );
}

function Controls({ q, active, sort, genre }: { q: string; active: string; sort: string; genre: string }) {
  const base = (extra: Record<string, string>) => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    Object.entries(extra).forEach(([k, v]) => v && p.set(k, v));
    const str = p.toString();
    return `/catalog${str ? "?" + str : ""}`;
  };
  const chips = [
    { label: "All", href: base({}), key: "all" },
    { label: "Interactive", href: base({ type: "Interactive" }), key: "Interactive" },
    { label: "Fiction", href: base({ type: "Fiction" }), key: "Fiction" },
    { label: "Non-Fiction", href: base({ type: "Non-Fiction" }), key: "Non-Fiction" },
    { label: "Free", href: base({ free: "1" }), key: "free" },
    { label: "Premium", href: base({ paid: "1" }), key: "paid" },
  ];
  // Show the curated genres, plus the active one if it isn't in the shortlist.
  const genreChips = [...new Set([...BROWSE_GENRES, ...(genre && !BROWSE_GENRES.includes(genre) ? [genre] : [])])].filter((g) => GENRES.includes(g as (typeof GENRES)[number]) || g === genre);
  const chip = (label: string, href: string, on: boolean) => (
    <a key={label} href={href} style={{ textDecoration: "none", padding: "0.4rem 0.95rem", fontSize: "0.85rem", borderRadius: 999, fontFamily: "var(--sans)", fontWeight: 600, background: on ? "var(--gold)" : "color-mix(in srgb, var(--gold) 12%, transparent)", color: on ? "#12100E" : "var(--ivory-muted)", border: "1px solid var(--border)", whiteSpace: "nowrap" }}>{label}</a>
  );
  return (
    <section className="section" style={{ paddingTop: "1.2rem", paddingBottom: 0 }}>
      <form action="/catalog" method="get" style={{ marginBottom: "1rem", maxWidth: 660 }}>
        <input type="hidden" name="sort" value={sort} />
        {/* One joined pill: field + button share a border and never break apart. */}
        <div style={{ display: "flex", alignItems: "stretch", background: "var(--stone)", border: "1px solid var(--border)", borderRadius: 999, overflow: "hidden" }}>
          <input
            name="q"
            defaultValue={q}
            type="text"
            placeholder="Search titles or authors…"
            aria-label="Search books"
            style={{ flex: 1, minWidth: 0, background: "transparent", border: "none", color: "var(--ivory)", fontFamily: "var(--sans)", fontSize: "0.95rem", padding: "0.65rem 0.5rem 0.65rem 1.1rem", outline: "none" }}
          />
          <button type="submit" className="btn btn-gold" style={{ borderRadius: 0, padding: "0.65rem 1.3rem", whiteSpace: "nowrap", flexShrink: 0 }}>Search</button>
        </div>
        <div style={{ marginTop: "0.6rem" }}>
          <CatalogSort value={sort} />
        </div>
      </form>
      <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap", marginBottom: "0.7rem" }}>
        {chips.map((c) => chip(c.label, c.href, active === c.key && !genre))}
      </div>
      {/* Genres tucked into a native disclosure so the row never becomes a wall
          of chips on mobile. Fully keyboard-accessible, no JS required. */}
      <details className="cat-genres" open={!!genre}>
        <summary>
          <span>{genre ? `Genre: ${genre}` : "Browse by genre"}</span>
          <span className="cat-genres-caret" aria-hidden="true">▾</span>
        </summary>
        <div className="cat-genres-panel">
          {chip("All genres", base({}), !genre)}
          {genreChips.map((g) => chip(g, base({ genre: g }), genre === g))}
        </div>
      </details>
    </section>
  );
}

export default async function Catalog({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; type?: string; free?: string; paid?: string; sort?: string; genre?: string; tag?: string; unlimited?: string }>;
}) {
  const { q, type, free, paid, sort, genre, tag, unlimited } = await searchParams;
  const unlimitedOnly = unlimited === "1" || unlimited === "true";
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  // Guests can browse; mature titles stay hidden unless a signed-in reader opts in.
  let showMature = false;
  if (user) {
    const sm = await supabase.from("profiles").select("show_mature").eq("id", user.id).maybeSingle();
    showMature = sm.data?.show_mature ?? false;
  }
  const allowed = allowedRatings(showMature);

  const term = (q ?? "").trim();
  const safe = term.replace(/[,()*]/g, " ").trim();
  const typeFilter = (type ?? "").trim();
  const genreFilter = (genre ?? "").trim();
  const tagFilter = (tag ?? "").trim();
  const freeOnly = free === "1" || free === "true";
  const paidOnly = paid === "1" || paid === "true";
  const sortKey = (sort ?? "").trim();
  // A chosen sort also switches to the flat grid — otherwise the shelf view
  // buckets books and the sort order is invisible (that's why sort "did nothing").
  const filtered = !!(safe || typeFilter || genreFilter || tagFilter || freeOnly || paidOnly || sortKey || unlimitedOnly);
  const activeChip = typeFilter === "Interactive" ? "Interactive" : typeFilter === "Fiction" ? "Fiction" : typeFilter === "Non-Fiction" ? "Non-Fiction" : freeOnly ? "free" : paidOnly ? "paid" : "all";

  const runQuery = (withAge: boolean) => {
    let query = supabase
      .from("books")
      .select(withAge ? "id, title, author, price, type, is_free, age_rating, rating, category, cover_url" : "id, title, author, price, type, is_free, rating, category, cover_url");
    if (withAge) query = query.eq("is_published", true).in("age_rating", allowed);
    if (typeFilter) query = query.eq("type", typeFilter);
    if (genreFilter) {
      query = query.eq("category", genreFilter);
      // Interactive is its own genre — keep interactive books out of the
      // regular genre pages (Romance, Fantasy, …) so genres don't cross-mix.
      if (typeFilter !== "Interactive") query = query.neq("type", "Interactive");
    }
    if (tagFilter) query = query.contains("tags", [tagFilter]);
    if (freeOnly) query = query.or("price.eq.0,is_free.eq.true");
    if (paidOnly) query = query.gt("price", 0);
    // Books you can keep with an Unlimited trial or box (migration 0044).
    if (unlimitedOnly) query = query.gt("price", 0).eq("allow_unlimited", true);
    if (safe) query = query.or(`title.ilike.%${safe}%,author.ilike.%${safe}%`);
    if (sortKey === "title") query = query.order("title", { ascending: true });
    else if (sortKey === "rating") query = query.order("rating", { ascending: false });
    else if (sortKey === "price-asc") query = query.order("price", { ascending: true });
    else if (sortKey === "price-desc") query = query.order("price", { ascending: false });
    else query = query.order("id", { ascending: false });
    return query.limit(filtered ? 48 : 80);
  };
  let res = await runQuery(true);
  if (res.error) res = await runQuery(false); // age_rating not migrated yet
  const books = (res.data ?? []) as unknown as CatBook[];

  // ---------- Filtered / search view: a single flat grid ----------
  if (filtered) {
    const heading = term ? `Results for “${term}”` : tagFilter ? `${tagFilter}` : genreFilter ? `${genreFilter}` : freeOnly ? "Free to Read" : paidOnly ? "Premium Reads" : typeFilter ? `${typeFilter} stories` : "Catalog";
    return (
      <>
        <AppNav />
        <Controls q={term} active={activeChip} sort={sortKey} genre={genreFilter} />
        <section className="section">
          <div className="section-header">
            <h2>{heading}</h2>
          </div>
          {books.length > 0 ? (
            <div className="book-grid-mini">
              {books.map((b) => <BookMini key={b.id} book={b} />)}
            </div>
          ) : (
            <div style={{ border: "1px solid var(--border)", borderRadius: 16, padding: "3rem 2rem", textAlign: "center", background: "var(--stone)" }}>
              <p style={{ fontSize: "1.2rem", marginBottom: "0.5rem" }}>{term ? "No books match your search." : "Nothing here yet."}</p>
              <p style={{ color: "var(--muted)", maxWidth: 440, margin: "0 auto" }}>
                {term ? "Try a different title or author." : "Published books will appear here."}
              </p>
            </div>
          )}
        </section>
      </>
    );
  }

  // ---------- Default view: shelves, like the home page ----------
  const isFree = (b: CatBook) => (b.price ?? 0) <= 0 || b.is_free === true;
  const isInteractive = (b: CatBook) => (b.type || "").toLowerCase() === "interactive";
  const interactive = books.filter(isInteractive);
  const freeReads = books.filter((b) => isFree(b) && !isInteractive(b));
  const premium = books.filter((b) => !isFree(b) && !isInteractive(b));

  return (
    <>
      <AppNav />
      <Controls q={term} active={activeChip} sort={sortKey} genre={genreFilter} />
      <section className="section" style={{ paddingBottom: 0 }}>
        <div className="section-header">
          <h2>Catalog</h2>
        </div>
        {books.length === 0 ? (
          <div style={{ border: "1px solid var(--border)", borderRadius: 16, padding: "3rem 2rem", textAlign: "center", background: "var(--stone)" }}>
            <p style={{ fontSize: "1.2rem", marginBottom: "0.5rem" }}>The catalog is empty for now.</p>
            <p style={{ color: "var(--muted)", maxWidth: 440, margin: "0 auto" }}>Published books will appear here.</p>
          </div>
        ) : null}
      </section>

      <Shelf title="Interactive Stories" href="/catalog?type=Interactive" books={interactive} />
      <Shelf title="Free to Read" href="/catalog?free=1" books={freeReads} />
      <Shelf title="Premium Reads" href="/catalog?paid=1" books={premium} />

      <div style={{ paddingBottom: "3rem" }} />
    </>
  );
}
